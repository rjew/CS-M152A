/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/152/Russell_Jeffrey_Jack/pong_example/pong_example/ball_control.v";
static int ng1[] = {1, 0};
static int ng2[] = {400, 0};
static int ng3[] = {100, 0};
static int ng4[] = {2, 0};
static int ng5[] = {0, 0};



static void Initial_49_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(50, ng0);

LAB2:    xsi_set_current_line(51, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 1, 0LL);
    xsi_set_current_line(52, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 1, 0LL);
    xsi_set_current_line(53, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 10, 0LL);
    xsi_set_current_line(54, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t2, t1, 0, 0, 9, 0LL);
    xsi_set_current_line(56, ng0);
    t1 = ((char*)((ng4)));
    t2 = (t0 + 3528);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 2);
    xsi_set_current_line(57, ng0);
    t1 = ((char*)((ng4)));
    t2 = (t0 + 3688);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 2);

LAB1:    return;
}

static void Always_60_1(char *t0)
{
    char t13[8];
    char t14[8];
    char t22[8];
    char t30[8];
    char t85[8];
    char t86[8];
    char t90[8];
    char t138[8];
    char t139[8];
    char t157[8];
    char t162[8];
    char t166[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    char *t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    int t54;
    int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t68;
    char *t69;
    char *t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t87;
    char *t88;
    char *t89;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    char *t94;
    char *t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    char *t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    char *t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    char *t123;
    char *t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    char *t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    char *t135;
    char *t136;
    char *t137;
    char *t140;
    char *t141;
    char *t142;
    char *t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    char *t149;
    char *t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    char *t154;
    char *t155;
    char *t156;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    char *t163;
    char *t164;
    char *t165;
    char *t167;
    int t168;
    int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    char *t195;
    char *t196;
    char *t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    char *t209;
    char *t210;
    char *t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    char *t219;
    char *t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    int t228;
    unsigned int t229;
    unsigned int t230;
    unsigned int t231;
    unsigned int t232;
    char *t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    char *t239;
    char *t240;
    char *t241;
    char *t242;
    char *t243;

LAB0:    t1 = (t0 + 4856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(60, ng0);
    t2 = (t0 + 5176);
    *((int *)t2) = 1;
    t3 = (t0 + 4888);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(61, ng0);

LAB5:    xsi_set_current_line(62, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:
LAB8:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB10;

LAB11:
LAB12:    goto LAB2;

LAB6:    xsi_set_current_line(63, ng0);

LAB9:    xsi_set_current_line(64, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    xsi_set_current_line(65, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(66, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 10, 0LL);
    xsi_set_current_line(67, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 9, 0LL);
    xsi_set_current_line(69, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3528);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 2);
    xsi_set_current_line(70, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 3688);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 2);
    goto LAB8;

LAB10:    xsi_set_current_line(75, ng0);

LAB13:    xsi_set_current_line(76, ng0);
    t4 = (t0 + 2008U);
    t5 = *((char **)t4);
    memset(t14, 0, 8);
    t4 = (t14 + 4);
    t11 = (t5 + 4);
    t15 = *((unsigned int *)t5);
    t16 = (t15 >> 0);
    t17 = (t16 & 1);
    *((unsigned int *)t14) = t17;
    t18 = *((unsigned int *)t11);
    t19 = (t18 >> 0);
    t20 = (t19 & 1);
    *((unsigned int *)t4) = t20;
    t12 = (t0 + 2168U);
    t21 = *((char **)t12);
    memset(t22, 0, 8);
    t12 = (t22 + 4);
    t23 = (t21 + 4);
    t24 = *((unsigned int *)t21);
    t25 = (t24 >> 0);
    t26 = (t25 & 1);
    *((unsigned int *)t22) = t26;
    t27 = *((unsigned int *)t23);
    t28 = (t27 >> 0);
    t29 = (t28 & 1);
    *((unsigned int *)t12) = t29;
    t31 = *((unsigned int *)t14);
    t32 = *((unsigned int *)t22);
    t33 = (t31 & t32);
    *((unsigned int *)t30) = t33;
    t34 = (t14 + 4);
    t35 = (t22 + 4);
    t36 = (t30 + 4);
    t37 = *((unsigned int *)t34);
    t38 = *((unsigned int *)t35);
    t39 = (t37 | t38);
    *((unsigned int *)t36) = t39;
    t40 = *((unsigned int *)t36);
    t41 = (t40 != 0);
    if (t41 == 1)
        goto LAB14;

LAB15:
LAB16:    memset(t13, 0, 8);
    t62 = (t30 + 4);
    t63 = *((unsigned int *)t62);
    t64 = (~(t63));
    t65 = *((unsigned int *)t30);
    t66 = (t65 & t64);
    t67 = (t66 & 1U);
    if (t67 != 0)
        goto LAB20;

LAB18:    if (*((unsigned int *)t62) == 0)
        goto LAB17;

LAB19:    t68 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t68) = 1;

LAB20:    t69 = (t13 + 4);
    t70 = (t30 + 4);
    t71 = *((unsigned int *)t30);
    t72 = (~(t71));
    *((unsigned int *)t13) = t72;
    *((unsigned int *)t69) = 0;
    if (*((unsigned int *)t70) != 0)
        goto LAB22;

LAB21:    t77 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t77 & 1U);
    t78 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t78 & 1U);
    t79 = (t13 + 4);
    t80 = *((unsigned int *)t79);
    t81 = (~(t80));
    t82 = *((unsigned int *)t13);
    t83 = (t82 & t81);
    t84 = (t83 != 0);
    if (t84 > 0)
        goto LAB23;

LAB24:
LAB25:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 2328U);
    t3 = *((char **)t2);
    memset(t14, 0, 8);
    t2 = (t14 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t2) = t15;
    t5 = (t0 + 2488U);
    t11 = *((char **)t5);
    memset(t22, 0, 8);
    t5 = (t22 + 4);
    t12 = (t11 + 4);
    t16 = *((unsigned int *)t11);
    t17 = (t16 >> 0);
    t18 = (t17 & 1);
    *((unsigned int *)t22) = t18;
    t19 = *((unsigned int *)t12);
    t20 = (t19 >> 0);
    t24 = (t20 & 1);
    *((unsigned int *)t5) = t24;
    t25 = *((unsigned int *)t14);
    t26 = *((unsigned int *)t22);
    t27 = (t25 & t26);
    *((unsigned int *)t30) = t27;
    t21 = (t14 + 4);
    t23 = (t22 + 4);
    t34 = (t30 + 4);
    t28 = *((unsigned int *)t21);
    t29 = *((unsigned int *)t23);
    t31 = (t28 | t29);
    *((unsigned int *)t34) = t31;
    t32 = *((unsigned int *)t34);
    t33 = (t32 != 0);
    if (t33 == 1)
        goto LAB62;

LAB63:
LAB64:    memset(t13, 0, 8);
    t44 = (t30 + 4);
    t57 = *((unsigned int *)t44);
    t58 = (~(t57));
    t59 = *((unsigned int *)t30);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB68;

LAB66:    if (*((unsigned int *)t44) == 0)
        goto LAB65;

LAB67:    t45 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t45) = 1;

LAB68:    t62 = (t13 + 4);
    t68 = (t30 + 4);
    t63 = *((unsigned int *)t30);
    t64 = (~(t63));
    *((unsigned int *)t13) = t64;
    *((unsigned int *)t62) = 0;
    if (*((unsigned int *)t68) != 0)
        goto LAB70;

LAB69:    t72 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t72 & 1U);
    t73 = *((unsigned int *)t62);
    *((unsigned int *)t62) = (t73 & 1U);
    t69 = (t13 + 4);
    t74 = *((unsigned int *)t69);
    t75 = (~(t74));
    t76 = *((unsigned int *)t13);
    t77 = (t76 & t75);
    t78 = (t77 != 0);
    if (t78 > 0)
        goto LAB71;

LAB72:
LAB73:    goto LAB12;

LAB14:    t42 = *((unsigned int *)t30);
    t43 = *((unsigned int *)t36);
    *((unsigned int *)t30) = (t42 | t43);
    t44 = (t14 + 4);
    t45 = (t22 + 4);
    t46 = *((unsigned int *)t14);
    t47 = (~(t46));
    t48 = *((unsigned int *)t44);
    t49 = (~(t48));
    t50 = *((unsigned int *)t22);
    t51 = (~(t50));
    t52 = *((unsigned int *)t45);
    t53 = (~(t52));
    t54 = (t47 & t49);
    t55 = (t51 & t53);
    t56 = (~(t54));
    t57 = (~(t55));
    t58 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t58 & t56);
    t59 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t59 & t57);
    t60 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t60 & t56);
    t61 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t61 & t57);
    goto LAB16;

LAB17:    *((unsigned int *)t13) = 1;
    goto LAB20;

LAB22:    t73 = *((unsigned int *)t13);
    t74 = *((unsigned int *)t70);
    *((unsigned int *)t13) = (t73 | t74);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t70);
    *((unsigned int *)t69) = (t75 | t76);
    goto LAB21;

LAB23:    xsi_set_current_line(77, ng0);

LAB26:    xsi_set_current_line(78, ng0);
    t87 = (t0 + 1528U);
    t88 = *((char **)t87);
    t87 = (t0 + 1688U);
    t89 = *((char **)t87);
    t91 = *((unsigned int *)t88);
    t92 = *((unsigned int *)t89);
    t93 = (t91 | t92);
    *((unsigned int *)t90) = t93;
    t87 = (t88 + 4);
    t94 = (t89 + 4);
    t95 = (t90 + 4);
    t96 = *((unsigned int *)t87);
    t97 = *((unsigned int *)t94);
    t98 = (t96 | t97);
    *((unsigned int *)t95) = t98;
    t99 = *((unsigned int *)t95);
    t100 = (t99 != 0);
    if (t100 == 1)
        goto LAB27;

LAB28:
LAB29:    memset(t86, 0, 8);
    t117 = (t90 + 4);
    t118 = *((unsigned int *)t117);
    t119 = (~(t118));
    t120 = *((unsigned int *)t90);
    t121 = (t120 & t119);
    t122 = (t121 & 1U);
    if (t122 != 0)
        goto LAB30;

LAB31:    if (*((unsigned int *)t117) != 0)
        goto LAB32;

LAB33:    t124 = (t86 + 4);
    t125 = *((unsigned int *)t86);
    t126 = *((unsigned int *)t124);
    t127 = (t125 || t126);
    if (t127 > 0)
        goto LAB34;

LAB35:    t131 = *((unsigned int *)t86);
    t132 = (~(t131));
    t133 = *((unsigned int *)t124);
    t134 = (t132 || t133);
    if (t134 > 0)
        goto LAB36;

LAB37:    if (*((unsigned int *)t124) > 0)
        goto LAB38;

LAB39:    if (*((unsigned int *)t86) > 0)
        goto LAB40;

LAB41:    memcpy(t85, t166, 8);

LAB42:    t167 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t167, t85, 0, 0, 10, 0LL);
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 2168U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t13) = t8;
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t2) = t15;
    t5 = (t13 + 4);
    t16 = *((unsigned int *)t5);
    t17 = (~(t16));
    t18 = *((unsigned int *)t13);
    t19 = (t18 & t17);
    t20 = (t19 != 0);
    if (t20 > 0)
        goto LAB56;

LAB57:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t13) = t8;
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t2) = t15;
    t5 = (t13 + 4);
    t16 = *((unsigned int *)t5);
    t17 = (~(t16));
    t18 = *((unsigned int *)t13);
    t19 = (t18 & t17);
    t20 = (t19 != 0);
    if (t20 > 0)
        goto LAB59;

LAB60:
LAB61:
LAB58:    goto LAB25;

LAB27:    t101 = *((unsigned int *)t90);
    t102 = *((unsigned int *)t95);
    *((unsigned int *)t90) = (t101 | t102);
    t103 = (t88 + 4);
    t104 = (t89 + 4);
    t105 = *((unsigned int *)t103);
    t106 = (~(t105));
    t107 = *((unsigned int *)t88);
    t108 = (t107 & t106);
    t109 = *((unsigned int *)t104);
    t110 = (~(t109));
    t111 = *((unsigned int *)t89);
    t112 = (t111 & t110);
    t113 = (~(t108));
    t114 = (~(t112));
    t115 = *((unsigned int *)t95);
    *((unsigned int *)t95) = (t115 & t113);
    t116 = *((unsigned int *)t95);
    *((unsigned int *)t95) = (t116 & t114);
    goto LAB29;

LAB30:    *((unsigned int *)t86) = 1;
    goto LAB33;

LAB32:    t123 = (t86 + 4);
    *((unsigned int *)t86) = 1;
    *((unsigned int *)t123) = 1;
    goto LAB33;

LAB34:    t128 = (t0 + 2888);
    t129 = (t128 + 56U);
    t130 = *((char **)t129);
    goto LAB35;

LAB36:    t135 = (t0 + 2888);
    t136 = (t135 + 56U);
    t137 = *((char **)t136);
    t140 = (t0 + 3208);
    t141 = (t140 + 56U);
    t142 = *((char **)t141);
    memset(t139, 0, 8);
    t143 = (t142 + 4);
    t144 = *((unsigned int *)t143);
    t145 = (~(t144));
    t146 = *((unsigned int *)t142);
    t147 = (t146 & t145);
    t148 = (t147 & 1U);
    if (t148 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t143) != 0)
        goto LAB45;

LAB46:    t150 = (t139 + 4);
    t151 = *((unsigned int *)t139);
    t152 = *((unsigned int *)t150);
    t153 = (t151 || t152);
    if (t153 > 0)
        goto LAB47;

LAB48:    t158 = *((unsigned int *)t139);
    t159 = (~(t158));
    t160 = *((unsigned int *)t150);
    t161 = (t159 || t160);
    if (t161 > 0)
        goto LAB49;

LAB50:    if (*((unsigned int *)t150) > 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t139) > 0)
        goto LAB53;

LAB54:    memcpy(t138, t162, 8);

LAB55:    memset(t166, 0, 8);
    xsi_vlog_unsigned_add(t166, 10, t137, 10, t138, 10);
    goto LAB37;

LAB38:    xsi_vlog_unsigned_bit_combine(t85, 10, t130, 10, t166, 10);
    goto LAB42;

LAB40:    memcpy(t85, t130, 8);
    goto LAB42;

LAB43:    *((unsigned int *)t139) = 1;
    goto LAB46;

LAB45:    t149 = (t139 + 4);
    *((unsigned int *)t139) = 1;
    *((unsigned int *)t149) = 1;
    goto LAB46;

LAB47:    t154 = (t0 + 3528);
    t155 = (t154 + 56U);
    t156 = *((char **)t155);
    memcpy(t157, t156, 8);
    goto LAB48;

LAB49:    t163 = (t0 + 3528);
    t164 = (t163 + 56U);
    t165 = *((char **)t164);
    memset(t162, 0, 8);
    xsi_vlog_unsigned_unary_minus(t162, 10, t165, 2);
    goto LAB50;

LAB51:    xsi_vlog_unsigned_bit_combine(t138, 10, t157, 10, t162, 10);
    goto LAB55;

LAB53:    memcpy(t138, t157, 8);
    goto LAB55;

LAB56:    xsi_set_current_line(80, ng0);
    t11 = ((char*)((ng5)));
    t12 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    goto LAB58;

LAB59:    xsi_set_current_line(82, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    goto LAB61;

LAB62:    t37 = *((unsigned int *)t30);
    t38 = *((unsigned int *)t34);
    *((unsigned int *)t30) = (t37 | t38);
    t35 = (t14 + 4);
    t36 = (t22 + 4);
    t39 = *((unsigned int *)t14);
    t40 = (~(t39));
    t41 = *((unsigned int *)t35);
    t42 = (~(t41));
    t43 = *((unsigned int *)t22);
    t46 = (~(t43));
    t47 = *((unsigned int *)t36);
    t48 = (~(t47));
    t54 = (t40 & t42);
    t55 = (t46 & t48);
    t49 = (~(t54));
    t50 = (~(t55));
    t51 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t51 & t49);
    t52 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t52 & t50);
    t53 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t53 & t49);
    t56 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t56 & t50);
    goto LAB64;

LAB65:    *((unsigned int *)t13) = 1;
    goto LAB68;

LAB70:    t65 = *((unsigned int *)t13);
    t66 = *((unsigned int *)t68);
    *((unsigned int *)t13) = (t65 | t66);
    t67 = *((unsigned int *)t62);
    t71 = *((unsigned int *)t68);
    *((unsigned int *)t62) = (t67 | t71);
    goto LAB69;

LAB71:    xsi_set_current_line(86, ng0);

LAB74:    xsi_set_current_line(87, ng0);
    t70 = (t0 + 1528U);
    t79 = *((char **)t70);
    t70 = (t0 + 1688U);
    t87 = *((char **)t70);
    t80 = *((unsigned int *)t79);
    t81 = *((unsigned int *)t87);
    t82 = (t80 | t81);
    *((unsigned int *)t90) = t82;
    t70 = (t79 + 4);
    t88 = (t87 + 4);
    t89 = (t90 + 4);
    t83 = *((unsigned int *)t70);
    t84 = *((unsigned int *)t88);
    t91 = (t83 | t84);
    *((unsigned int *)t89) = t91;
    t92 = *((unsigned int *)t89);
    t93 = (t92 != 0);
    if (t93 == 1)
        goto LAB75;

LAB76:
LAB77:    memset(t86, 0, 8);
    t103 = (t90 + 4);
    t111 = *((unsigned int *)t103);
    t113 = (~(t111));
    t114 = *((unsigned int *)t90);
    t115 = (t114 & t113);
    t116 = (t115 & 1U);
    if (t116 != 0)
        goto LAB78;

LAB79:    if (*((unsigned int *)t103) != 0)
        goto LAB80;

LAB81:    t117 = (t86 + 4);
    t118 = *((unsigned int *)t86);
    t119 = *((unsigned int *)t117);
    t120 = (t118 || t119);
    if (t120 > 0)
        goto LAB82;

LAB83:    t121 = *((unsigned int *)t86);
    t122 = (~(t121));
    t125 = *((unsigned int *)t117);
    t126 = (t122 || t125);
    if (t126 > 0)
        goto LAB84;

LAB85:    if (*((unsigned int *)t117) > 0)
        goto LAB86;

LAB87:    if (*((unsigned int *)t86) > 0)
        goto LAB88;

LAB89:    memcpy(t85, t166, 8);

LAB90:    t164 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t164, t85, 0, 0, 9, 0LL);
    xsi_set_current_line(88, ng0);
    t2 = (t0 + 2488U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t13) = t8;
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t2) = t15;
    t5 = (t13 + 4);
    t16 = *((unsigned int *)t5);
    t17 = (~(t16));
    t18 = *((unsigned int *)t13);
    t19 = (t18 & t17);
    t20 = (t19 != 0);
    if (t20 > 0)
        goto LAB104;

LAB105:    xsi_set_current_line(103, ng0);
    t2 = (t0 + 2328U);
    t3 = *((char **)t2);
    memset(t13, 0, 8);
    t2 = (t13 + 4);
    t4 = (t3 + 4);
    t6 = *((unsigned int *)t3);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t13) = t8;
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    t15 = (t10 & 1);
    *((unsigned int *)t2) = t15;
    t5 = (t13 + 4);
    t16 = *((unsigned int *)t5);
    t17 = (~(t16));
    t18 = *((unsigned int *)t13);
    t19 = (t18 & t17);
    t20 = (t19 != 0);
    if (t20 > 0)
        goto LAB173;

LAB174:
LAB175:
LAB106:    goto LAB73;

LAB75:    t96 = *((unsigned int *)t90);
    t97 = *((unsigned int *)t89);
    *((unsigned int *)t90) = (t96 | t97);
    t94 = (t79 + 4);
    t95 = (t87 + 4);
    t98 = *((unsigned int *)t94);
    t99 = (~(t98));
    t100 = *((unsigned int *)t79);
    t108 = (t100 & t99);
    t101 = *((unsigned int *)t95);
    t102 = (~(t101));
    t105 = *((unsigned int *)t87);
    t112 = (t105 & t102);
    t106 = (~(t108));
    t107 = (~(t112));
    t109 = *((unsigned int *)t89);
    *((unsigned int *)t89) = (t109 & t106);
    t110 = *((unsigned int *)t89);
    *((unsigned int *)t89) = (t110 & t107);
    goto LAB77;

LAB78:    *((unsigned int *)t86) = 1;
    goto LAB81;

LAB80:    t104 = (t86 + 4);
    *((unsigned int *)t86) = 1;
    *((unsigned int *)t104) = 1;
    goto LAB81;

LAB82:    t123 = (t0 + 3048);
    t124 = (t123 + 56U);
    t128 = *((char **)t124);
    goto LAB83;

LAB84:    t129 = (t0 + 3048);
    t130 = (t129 + 56U);
    t135 = *((char **)t130);
    t136 = (t0 + 3368);
    t137 = (t136 + 56U);
    t140 = *((char **)t137);
    memset(t139, 0, 8);
    t141 = (t140 + 4);
    t127 = *((unsigned int *)t141);
    t131 = (~(t127));
    t132 = *((unsigned int *)t140);
    t133 = (t132 & t131);
    t134 = (t133 & 1U);
    if (t134 != 0)
        goto LAB91;

LAB92:    if (*((unsigned int *)t141) != 0)
        goto LAB93;

LAB94:    t143 = (t139 + 4);
    t144 = *((unsigned int *)t139);
    t145 = *((unsigned int *)t143);
    t146 = (t144 || t145);
    if (t146 > 0)
        goto LAB95;

LAB96:    t147 = *((unsigned int *)t139);
    t148 = (~(t147));
    t151 = *((unsigned int *)t143);
    t152 = (t148 || t151);
    if (t152 > 0)
        goto LAB97;

LAB98:    if (*((unsigned int *)t143) > 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t139) > 0)
        goto LAB101;

LAB102:    memcpy(t138, t162, 8);

LAB103:    memset(t166, 0, 8);
    xsi_vlog_unsigned_add(t166, 9, t135, 9, t138, 9);
    goto LAB85;

LAB86:    xsi_vlog_unsigned_bit_combine(t85, 9, t128, 9, t166, 9);
    goto LAB90;

LAB88:    memcpy(t85, t128, 8);
    goto LAB90;

LAB91:    *((unsigned int *)t139) = 1;
    goto LAB94;

LAB93:    t142 = (t139 + 4);
    *((unsigned int *)t139) = 1;
    *((unsigned int *)t142) = 1;
    goto LAB94;

LAB95:    t149 = (t0 + 3688);
    t150 = (t149 + 56U);
    t154 = *((char **)t150);
    memcpy(t157, t154, 8);
    goto LAB96;

LAB97:    t155 = (t0 + 3688);
    t156 = (t155 + 56U);
    t163 = *((char **)t156);
    memset(t162, 0, 8);
    xsi_vlog_unsigned_unary_minus(t162, 9, t163, 2);
    goto LAB98;

LAB99:    xsi_vlog_unsigned_bit_combine(t138, 9, t157, 9, t162, 9);
    goto LAB103;

LAB101:    memcpy(t138, t157, 8);
    goto LAB103;

LAB104:    xsi_set_current_line(89, ng0);

LAB107:    xsi_set_current_line(90, ng0);
    t11 = (t0 + 3208);
    t12 = (t11 + 56U);
    t21 = *((char **)t12);
    t23 = (t0 + 1848U);
    t34 = *((char **)t23);
    memset(t14, 0, 8);
    t23 = (t14 + 4);
    t35 = (t34 + 4);
    t24 = *((unsigned int *)t34);
    t25 = (t24 >> 0);
    t26 = (t25 & 1);
    *((unsigned int *)t14) = t26;
    t27 = *((unsigned int *)t35);
    t28 = (t27 >> 0);
    t29 = (t28 & 1);
    *((unsigned int *)t23) = t29;
    t31 = *((unsigned int *)t21);
    t32 = *((unsigned int *)t14);
    t33 = (t31 & t32);
    *((unsigned int *)t22) = t33;
    t36 = (t21 + 4);
    t44 = (t14 + 4);
    t45 = (t22 + 4);
    t37 = *((unsigned int *)t36);
    t38 = *((unsigned int *)t44);
    t39 = (t37 | t38);
    *((unsigned int *)t45) = t39;
    t40 = *((unsigned int *)t45);
    t41 = (t40 != 0);
    if (t41 == 1)
        goto LAB108;

LAB109:
LAB110:    t69 = (t0 + 3208);
    t70 = (t69 + 56U);
    t79 = *((char **)t70);
    memset(t30, 0, 8);
    t87 = (t79 + 4);
    t63 = *((unsigned int *)t87);
    t64 = (~(t63));
    t65 = *((unsigned int *)t79);
    t66 = (t65 & t64);
    t67 = (t66 & 1U);
    if (t67 != 0)
        goto LAB114;

LAB112:    if (*((unsigned int *)t87) == 0)
        goto LAB111;

LAB113:    t88 = (t30 + 4);
    *((unsigned int *)t30) = 1;
    *((unsigned int *)t88) = 1;

LAB114:    t89 = (t30 + 4);
    t94 = (t79 + 4);
    t71 = *((unsigned int *)t79);
    t72 = (~(t71));
    *((unsigned int *)t30) = t72;
    *((unsigned int *)t89) = 0;
    if (*((unsigned int *)t94) != 0)
        goto LAB116;

LAB115:    t77 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t77 & 1U);
    t78 = *((unsigned int *)t89);
    *((unsigned int *)t89) = (t78 & 1U);
    t95 = (t0 + 1848U);
    t103 = *((char **)t95);
    memset(t85, 0, 8);
    t95 = (t85 + 4);
    t104 = (t103 + 4);
    t80 = *((unsigned int *)t103);
    t81 = (t80 >> 2);
    t82 = (t81 & 1);
    *((unsigned int *)t85) = t82;
    t83 = *((unsigned int *)t104);
    t84 = (t83 >> 2);
    t91 = (t84 & 1);
    *((unsigned int *)t95) = t91;
    t92 = *((unsigned int *)t30);
    t93 = *((unsigned int *)t85);
    t96 = (t92 & t93);
    *((unsigned int *)t86) = t96;
    t117 = (t30 + 4);
    t123 = (t85 + 4);
    t124 = (t86 + 4);
    t97 = *((unsigned int *)t117);
    t98 = *((unsigned int *)t123);
    t99 = (t97 | t98);
    *((unsigned int *)t124) = t99;
    t100 = *((unsigned int *)t124);
    t101 = (t100 != 0);
    if (t101 == 1)
        goto LAB117;

LAB118:
LAB119:    t125 = *((unsigned int *)t22);
    t126 = *((unsigned int *)t86);
    t127 = (t125 | t126);
    *((unsigned int *)t90) = t127;
    t130 = (t22 + 4);
    t135 = (t86 + 4);
    t136 = (t90 + 4);
    t131 = *((unsigned int *)t130);
    t132 = *((unsigned int *)t135);
    t133 = (t131 | t132);
    *((unsigned int *)t136) = t133;
    t134 = *((unsigned int *)t136);
    t144 = (t134 != 0);
    if (t144 == 1)
        goto LAB120;

LAB121:
LAB122:    t141 = (t90 + 4);
    t171 = *((unsigned int *)t141);
    t172 = (~(t171));
    t173 = *((unsigned int *)t90);
    t174 = (t173 & t172);
    t175 = (t174 != 0);
    if (t175 > 0)
        goto LAB123;

LAB124:    xsi_set_current_line(96, ng0);
    t2 = (t0 + 3208);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t4 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (~(t6));
    t8 = *((unsigned int *)t4);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB139;

LAB137:    if (*((unsigned int *)t5) == 0)
        goto LAB136;

LAB138:    t11 = (t13 + 4);
    *((unsigned int *)t13) = 1;
    *((unsigned int *)t11) = 1;

LAB139:    t12 = (t13 + 4);
    t21 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = (~(t15));
    *((unsigned int *)t13) = t16;
    *((unsigned int *)t12) = 0;
    if (*((unsigned int *)t21) != 0)
        goto LAB141;

LAB140:    t24 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t24 & 1U);
    t25 = *((unsigned int *)t12);
    *((unsigned int *)t12) = (t25 & 1U);
    t23 = (t0 + 1848U);
    t34 = *((char **)t23);
    memset(t14, 0, 8);
    t23 = (t14 + 4);
    t35 = (t34 + 4);
    t26 = *((unsigned int *)t34);
    t27 = (t26 >> 0);
    t28 = (t27 & 1);
    *((unsigned int *)t14) = t28;
    t29 = *((unsigned int *)t35);
    t31 = (t29 >> 0);
    t32 = (t31 & 1);
    *((unsigned int *)t23) = t32;
    t33 = *((unsigned int *)t13);
    t37 = *((unsigned int *)t14);
    t38 = (t33 & t37);
    *((unsigned int *)t22) = t38;
    t36 = (t13 + 4);
    t44 = (t14 + 4);
    t45 = (t22 + 4);
    t39 = *((unsigned int *)t36);
    t40 = *((unsigned int *)t44);
    t41 = (t39 | t40);
    *((unsigned int *)t45) = t41;
    t42 = *((unsigned int *)t45);
    t43 = (t42 != 0);
    if (t43 == 1)
        goto LAB142;

LAB143:
LAB144:    t69 = (t0 + 3208);
    t70 = (t69 + 56U);
    t79 = *((char **)t70);
    t87 = (t0 + 1848U);
    t88 = *((char **)t87);
    memset(t30, 0, 8);
    t87 = (t30 + 4);
    t89 = (t88 + 4);
    t65 = *((unsigned int *)t88);
    t66 = (t65 >> 2);
    t67 = (t66 & 1);
    *((unsigned int *)t30) = t67;
    t71 = *((unsigned int *)t89);
    t72 = (t71 >> 2);
    t73 = (t72 & 1);
    *((unsigned int *)t87) = t73;
    t74 = *((unsigned int *)t79);
    t75 = *((unsigned int *)t30);
    t76 = (t74 & t75);
    *((unsigned int *)t85) = t76;
    t94 = (t79 + 4);
    t95 = (t30 + 4);
    t103 = (t85 + 4);
    t77 = *((unsigned int *)t94);
    t78 = *((unsigned int *)t95);
    t80 = (t77 | t78);
    *((unsigned int *)t103) = t80;
    t81 = *((unsigned int *)t103);
    t82 = (t81 != 0);
    if (t82 == 1)
        goto LAB145;

LAB146:
LAB147:    t110 = *((unsigned int *)t22);
    t111 = *((unsigned int *)t85);
    t113 = (t110 | t111);
    *((unsigned int *)t86) = t113;
    t123 = (t22 + 4);
    t124 = (t85 + 4);
    t128 = (t86 + 4);
    t114 = *((unsigned int *)t123);
    t115 = *((unsigned int *)t124);
    t116 = (t114 | t115);
    *((unsigned int *)t128) = t116;
    t118 = *((unsigned int *)t128);
    t119 = (t118 != 0);
    if (t119 == 1)
        goto LAB148;

LAB149:
LAB150:    t135 = (t86 + 4);
    t146 = *((unsigned int *)t135);
    t147 = (~(t146));
    t148 = *((unsigned int *)t86);
    t151 = (t148 & t147);
    t152 = (t151 != 0);
    if (t152 > 0)
        goto LAB151;

LAB152:
LAB153:
LAB125:    xsi_set_current_line(101, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB106;

LAB108:    t42 = *((unsigned int *)t22);
    t43 = *((unsigned int *)t45);
    *((unsigned int *)t22) = (t42 | t43);
    t62 = (t21 + 4);
    t68 = (t14 + 4);
    t46 = *((unsigned int *)t21);
    t47 = (~(t46));
    t48 = *((unsigned int *)t62);
    t49 = (~(t48));
    t50 = *((unsigned int *)t14);
    t51 = (~(t50));
    t52 = *((unsigned int *)t68);
    t53 = (~(t52));
    t54 = (t47 & t49);
    t55 = (t51 & t53);
    t56 = (~(t54));
    t57 = (~(t55));
    t58 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t58 & t56);
    t59 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t59 & t57);
    t60 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t60 & t56);
    t61 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t61 & t57);
    goto LAB110;

LAB111:    *((unsigned int *)t30) = 1;
    goto LAB114;

LAB116:    t73 = *((unsigned int *)t30);
    t74 = *((unsigned int *)t94);
    *((unsigned int *)t30) = (t73 | t74);
    t75 = *((unsigned int *)t89);
    t76 = *((unsigned int *)t94);
    *((unsigned int *)t89) = (t75 | t76);
    goto LAB115;

LAB117:    t102 = *((unsigned int *)t86);
    t105 = *((unsigned int *)t124);
    *((unsigned int *)t86) = (t102 | t105);
    t128 = (t30 + 4);
    t129 = (t85 + 4);
    t106 = *((unsigned int *)t30);
    t107 = (~(t106));
    t109 = *((unsigned int *)t128);
    t110 = (~(t109));
    t111 = *((unsigned int *)t85);
    t113 = (~(t111));
    t114 = *((unsigned int *)t129);
    t115 = (~(t114));
    t108 = (t107 & t110);
    t112 = (t113 & t115);
    t116 = (~(t108));
    t118 = (~(t112));
    t119 = *((unsigned int *)t124);
    *((unsigned int *)t124) = (t119 & t116);
    t120 = *((unsigned int *)t124);
    *((unsigned int *)t124) = (t120 & t118);
    t121 = *((unsigned int *)t86);
    *((unsigned int *)t86) = (t121 & t116);
    t122 = *((unsigned int *)t86);
    *((unsigned int *)t86) = (t122 & t118);
    goto LAB119;

LAB120:    t145 = *((unsigned int *)t90);
    t146 = *((unsigned int *)t136);
    *((unsigned int *)t90) = (t145 | t146);
    t137 = (t22 + 4);
    t140 = (t86 + 4);
    t147 = *((unsigned int *)t137);
    t148 = (~(t147));
    t151 = *((unsigned int *)t22);
    t168 = (t151 & t148);
    t152 = *((unsigned int *)t140);
    t153 = (~(t152));
    t158 = *((unsigned int *)t86);
    t169 = (t158 & t153);
    t159 = (~(t168));
    t160 = (~(t169));
    t161 = *((unsigned int *)t136);
    *((unsigned int *)t136) = (t161 & t159);
    t170 = *((unsigned int *)t136);
    *((unsigned int *)t136) = (t170 & t160);
    goto LAB122;

LAB123:    xsi_set_current_line(91, ng0);

LAB126:    xsi_set_current_line(92, ng0);
    t142 = (t0 + 3208);
    t143 = (t142 + 56U);
    t149 = *((char **)t143);
    memset(t138, 0, 8);
    t150 = (t149 + 4);
    t176 = *((unsigned int *)t150);
    t177 = (~(t176));
    t178 = *((unsigned int *)t149);
    t179 = (t178 & t177);
    t180 = (t179 & 1U);
    if (t180 != 0)
        goto LAB130;

LAB128:    if (*((unsigned int *)t150) == 0)
        goto LAB127;

LAB129:    t154 = (t138 + 4);
    *((unsigned int *)t138) = 1;
    *((unsigned int *)t154) = 1;

LAB130:    t155 = (t138 + 4);
    t156 = (t149 + 4);
    t181 = *((unsigned int *)t149);
    t182 = (~(t181));
    *((unsigned int *)t138) = t182;
    *((unsigned int *)t155) = 0;
    if (*((unsigned int *)t156) != 0)
        goto LAB132;

LAB131:    t187 = *((unsigned int *)t138);
    *((unsigned int *)t138) = (t187 & 1U);
    t188 = *((unsigned int *)t155);
    *((unsigned int *)t155) = (t188 & 1U);
    t163 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t163, t138, 0, 0, 1, 0LL);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 3528);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t13, 0, 8);
    t5 = (t13 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 1);
    t8 = (t7 & 1);
    *((unsigned int *)t13) = t8;
    t9 = *((unsigned int *)t11);
    t10 = (t9 >> 1);
    t15 = (t10 & 1);
    *((unsigned int *)t5) = t15;
    t12 = (t13 + 4);
    t16 = *((unsigned int *)t12);
    t17 = (~(t16));
    t18 = *((unsigned int *)t13);
    t19 = (t18 & t17);
    t20 = (t19 != 0);
    if (t20 > 0)
        goto LAB133;

LAB134:
LAB135:    goto LAB125;

LAB127:    *((unsigned int *)t138) = 1;
    goto LAB130;

LAB132:    t183 = *((unsigned int *)t138);
    t184 = *((unsigned int *)t156);
    *((unsigned int *)t138) = (t183 | t184);
    t185 = *((unsigned int *)t155);
    t186 = *((unsigned int *)t156);
    *((unsigned int *)t155) = (t185 | t186);
    goto LAB131;

LAB133:    xsi_set_current_line(94, ng0);
    t21 = (t0 + 3528);
    t23 = (t21 + 56U);
    t34 = *((char **)t23);
    t35 = ((char*)((ng1)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_minus(t14, 32, t34, 2, t35, 32);
    t36 = (t0 + 3528);
    xsi_vlogvar_assign_value(t36, t14, 0, 0, 2);
    goto LAB135;

LAB136:    *((unsigned int *)t13) = 1;
    goto LAB139;

LAB141:    t17 = *((unsigned int *)t13);
    t18 = *((unsigned int *)t21);
    *((unsigned int *)t13) = (t17 | t18);
    t19 = *((unsigned int *)t12);
    t20 = *((unsigned int *)t21);
    *((unsigned int *)t12) = (t19 | t20);
    goto LAB140;

LAB142:    t46 = *((unsigned int *)t22);
    t47 = *((unsigned int *)t45);
    *((unsigned int *)t22) = (t46 | t47);
    t62 = (t13 + 4);
    t68 = (t14 + 4);
    t48 = *((unsigned int *)t13);
    t49 = (~(t48));
    t50 = *((unsigned int *)t62);
    t51 = (~(t50));
    t52 = *((unsigned int *)t14);
    t53 = (~(t52));
    t56 = *((unsigned int *)t68);
    t57 = (~(t56));
    t54 = (t49 & t51);
    t55 = (t53 & t57);
    t58 = (~(t54));
    t59 = (~(t55));
    t60 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t60 & t58);
    t61 = *((unsigned int *)t45);
    *((unsigned int *)t45) = (t61 & t59);
    t63 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t63 & t58);
    t64 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t64 & t59);
    goto LAB144;

LAB145:    t83 = *((unsigned int *)t85);
    t84 = *((unsigned int *)t103);
    *((unsigned int *)t85) = (t83 | t84);
    t104 = (t79 + 4);
    t117 = (t30 + 4);
    t91 = *((unsigned int *)t79);
    t92 = (~(t91));
    t93 = *((unsigned int *)t104);
    t96 = (~(t93));
    t97 = *((unsigned int *)t30);
    t98 = (~(t97));
    t99 = *((unsigned int *)t117);
    t100 = (~(t99));
    t108 = (t92 & t96);
    t112 = (t98 & t100);
    t101 = (~(t108));
    t102 = (~(t112));
    t105 = *((unsigned int *)t103);
    *((unsigned int *)t103) = (t105 & t101);
    t106 = *((unsigned int *)t103);
    *((unsigned int *)t103) = (t106 & t102);
    t107 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t107 & t101);
    t109 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t109 & t102);
    goto LAB147;

LAB148:    t120 = *((unsigned int *)t86);
    t121 = *((unsigned int *)t128);
    *((unsigned int *)t86) = (t120 | t121);
    t129 = (t22 + 4);
    t130 = (t85 + 4);
    t122 = *((unsigned int *)t129);
    t125 = (~(t122));
    t126 = *((unsigned int *)t22);
    t168 = (t126 & t125);
    t127 = *((unsigned int *)t130);
    t131 = (~(t127));
    t132 = *((unsigned int *)t85);
    t169 = (t132 & t131);
    t133 = (~(t168));
    t134 = (~(t169));
    t144 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t144 & t133);
    t145 = *((unsigned int *)t128);
    *((unsigned int *)t128) = (t145 & t134);
    goto LAB150;

LAB151:    xsi_set_current_line(97, ng0);

LAB154:    xsi_set_current_line(98, ng0);
    t136 = (t0 + 3528);
    t137 = (t136 + 56U);
    t140 = *((char **)t137);
    memset(t138, 0, 8);
    t141 = (t138 + 4);
    t142 = (t140 + 4);
    t153 = *((unsigned int *)t140);
    t158 = (t153 >> 1);
    t159 = (t158 & 1);
    *((unsigned int *)t138) = t159;
    t160 = *((unsigned int *)t142);
    t161 = (t160 >> 1);
    t170 = (t161 & 1);
    *((unsigned int *)t141) = t170;
    memset(t90, 0, 8);
    t143 = (t138 + 4);
    t171 = *((unsigned int *)t143);
    t172 = (~(t171));
    t173 = *((unsigned int *)t138);
    t174 = (t173 & t172);
    t175 = (t174 & 1U);
    if (t175 != 0)
        goto LAB158;

LAB156:    if (*((unsigned int *)t143) == 0)
        goto LAB155;

LAB157:    t149 = (t90 + 4);
    *((unsigned int *)t90) = 1;
    *((unsigned int *)t149) = 1;

LAB158:    t150 = (t90 + 4);
    t154 = (t138 + 4);
    t176 = *((unsigned int *)t138);
    t177 = (~(t176));
    *((unsigned int *)t90) = t177;
    *((unsigned int *)t150) = 0;
    if (*((unsigned int *)t154) != 0)
        goto LAB160;

LAB159:    t182 = *((unsigned int *)t90);
    *((unsigned int *)t90) = (t182 & 1U);
    t183 = *((unsigned int *)t150);
    *((unsigned int *)t150) = (t183 & 1U);
    t155 = (t0 + 3528);
    t156 = (t155 + 56U);
    t163 = *((char **)t156);
    memset(t157, 0, 8);
    t164 = (t157 + 4);
    t165 = (t163 + 4);
    t184 = *((unsigned int *)t163);
    t185 = (t184 >> 0);
    t186 = (t185 & 1);
    *((unsigned int *)t157) = t186;
    t187 = *((unsigned int *)t165);
    t188 = (t187 >> 0);
    t189 = (t188 & 1);
    *((unsigned int *)t164) = t189;
    memset(t139, 0, 8);
    t167 = (t157 + 4);
    t190 = *((unsigned int *)t167);
    t191 = (~(t190));
    t192 = *((unsigned int *)t157);
    t193 = (t192 & t191);
    t194 = (t193 & 1U);
    if (t194 != 0)
        goto LAB164;

LAB162:    if (*((unsigned int *)t167) == 0)
        goto LAB161;

LAB163:    t195 = (t139 + 4);
    *((unsigned int *)t139) = 1;
    *((unsigned int *)t195) = 1;

LAB164:    t196 = (t139 + 4);
    t197 = (t157 + 4);
    t198 = *((unsigned int *)t157);
    t199 = (~(t198));
    *((unsigned int *)t139) = t199;
    *((unsigned int *)t196) = 0;
    if (*((unsigned int *)t197) != 0)
        goto LAB166;

LAB165:    t204 = *((unsigned int *)t139);
    *((unsigned int *)t139) = (t204 & 1U);
    t205 = *((unsigned int *)t196);
    *((unsigned int *)t196) = (t205 & 1U);
    t206 = *((unsigned int *)t90);
    t207 = *((unsigned int *)t139);
    t208 = (t206 | t207);
    *((unsigned int *)t162) = t208;
    t209 = (t90 + 4);
    t210 = (t139 + 4);
    t211 = (t162 + 4);
    t212 = *((unsigned int *)t209);
    t213 = *((unsigned int *)t210);
    t214 = (t212 | t213);
    *((unsigned int *)t211) = t214;
    t215 = *((unsigned int *)t211);
    t216 = (t215 != 0);
    if (t216 == 1)
        goto LAB167;

LAB168:
LAB169:    t233 = (t162 + 4);
    t234 = *((unsigned int *)t233);
    t235 = (~(t234));
    t236 = *((unsigned int *)t162);
    t237 = (t236 & t235);
    t238 = (t237 != 0);
    if (t238 > 0)
        goto LAB170;

LAB171:
LAB172:    goto LAB153;

LAB155:    *((unsigned int *)t90) = 1;
    goto LAB158;

LAB160:    t178 = *((unsigned int *)t90);
    t179 = *((unsigned int *)t154);
    *((unsigned int *)t90) = (t178 | t179);
    t180 = *((unsigned int *)t150);
    t181 = *((unsigned int *)t154);
    *((unsigned int *)t150) = (t180 | t181);
    goto LAB159;

LAB161:    *((unsigned int *)t139) = 1;
    goto LAB164;

LAB166:    t200 = *((unsigned int *)t139);
    t201 = *((unsigned int *)t197);
    *((unsigned int *)t139) = (t200 | t201);
    t202 = *((unsigned int *)t196);
    t203 = *((unsigned int *)t197);
    *((unsigned int *)t196) = (t202 | t203);
    goto LAB165;

LAB167:    t217 = *((unsigned int *)t162);
    t218 = *((unsigned int *)t211);
    *((unsigned int *)t162) = (t217 | t218);
    t219 = (t90 + 4);
    t220 = (t139 + 4);
    t221 = *((unsigned int *)t219);
    t222 = (~(t221));
    t223 = *((unsigned int *)t90);
    t224 = (t223 & t222);
    t225 = *((unsigned int *)t220);
    t226 = (~(t225));
    t227 = *((unsigned int *)t139);
    t228 = (t227 & t226);
    t229 = (~(t224));
    t230 = (~(t228));
    t231 = *((unsigned int *)t211);
    *((unsigned int *)t211) = (t231 & t229);
    t232 = *((unsigned int *)t211);
    *((unsigned int *)t211) = (t232 & t230);
    goto LAB169;

LAB170:    xsi_set_current_line(99, ng0);
    t239 = (t0 + 3528);
    t240 = (t239 + 56U);
    t241 = *((char **)t240);
    t242 = ((char*)((ng1)));
    memset(t166, 0, 8);
    xsi_vlog_unsigned_add(t166, 32, t241, 2, t242, 32);
    t243 = (t0 + 3528);
    xsi_vlogvar_assign_value(t243, t166, 0, 0, 2);
    goto LAB172;

LAB173:    xsi_set_current_line(104, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 3368);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 1, 0LL);
    goto LAB175;

}


extern void work_m_00000000001832835157_3708056319_init()
{
	static char *pe[] = {(void *)Initial_49_0,(void *)Always_60_1};
	xsi_register_didat("work_m_00000000001832835157_3708056319", "isim/speed_tb_isim_beh.exe.sim/work/m_00000000001832835157_3708056319.didat");
	xsi_register_executes(pe);
}
